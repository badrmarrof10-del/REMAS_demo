const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
let cart=0;
const modal=$('#modal'), toast=$('#toast');
function openModal(title,text){$('#modalTitle').textContent=title;$('#modalText').textContent=text;modal.classList.add('open')}
$('#closeModal').onclick=()=>modal.classList.remove('open'); modal.onclick=e=>{if(e.target===modal)modal.classList.remove('open')};
$('#supplyBtn').onclick=()=>openModal('طلب توريد','في النسخة النهائية نربط النموذج مباشرة ببيانات التواصل الرسمية أو واتساب الشركة.');
$('#searchBtn').onclick=()=>openModal('بحث سريع','ميزة البحث جاهزة كواجهة Demo. في النسخة الحقيقية يمكن ربطها بقاعدة المنتجات والفلاتر والمقاسات والألوان.');
$('#cartBtn').onclick=()=>openModal('سلة المشتريات',cart?`عندك ${cart} منتج في السلة — في النسخة النهائية نكمل بيانات العميل والشحن والدفع.`:'السلة فاضية حاليًا. اضغط «استكشف» على أي منتج لإضافته.');
$$('.view').forEach(b=>b.onclick=()=>{cart++;$('#cartCount').textContent=cart;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),1800)});
const io=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add('visible')),{threshold:.12});$$('.reveal').forEach(x=>io.observe(x));
$$('.tilt').forEach(card=>{card.addEventListener('mousemove',e=>{if(innerWidth<800)return;const r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;card.style.transform=`rotateX(${(-y*6).toFixed(2)}deg) rotateY(${(x*8).toFixed(2)}deg) translateY(-5px)`});card.addEventListener('mouseleave',()=>card.style.transform='')});
$('#sendDemo').onclick=()=>{modal.classList.remove('open');toast.textContent='تم إرسال الطلب التجريبي ✦';toast.classList.add('show');setTimeout(()=>{toast.classList.remove('show');toast.textContent='تمت إضافة المنتج للسلة ✦'},1800)};
